const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.getElementById('nav-menu');
const filterButtons = document.querySelectorAll('.filter-btn');
const cards = document.querySelectorAll('.card');
const surpriseButton = document.getElementById('surprise-btn');
const featuredDestination = document.getElementById('featured-destination');
const rotateNoteButton = document.getElementById('rotate-note-btn');
const experienceNote = document.getElementById('experience-note');
const contactForm = document.getElementById('contact-form');
const formFeedback = document.getElementById('form-feedback');
const counterElements = document.querySelectorAll('[data-count]');
const revealElements = document.querySelectorAll('.card, .hero-copy, .hero-panel, .highlight-box, .media-grid article, .table-wrap, .contact-card');
const routeCards = document.querySelectorAll('.card[data-route]');
const mapElement = document.getElementById('city-map');
const mapStatus = document.getElementById('map-status');
const mapRouteTitle = document.getElementById('map-route-title');
const mapRouteDescription = document.getElementById('map-route-description');
const googleMapsApiKey = document.querySelector('meta[name="google-maps-api-key"]')?.content?.trim() || '';

const surpriseDestinations = ['Lisbonne', 'Reykjavik', 'Seville', 'Quebec', 'Marrakech'];
const experienceNotes = [
	'Un city-break bien construit peut suffire pour depayser sans perdre une semaine complete.',
	'Les voyages les plus memorables combinent un point fort local et du temps libre non planifie.',
	"Un bon itineraire laisse de la place a l'imprevu sans sacrifier les moments importants."
];

const routeConfigurations = {
	paris: {
		title: 'Paris',
		description: 'Trajet culturel entre la Tour Eiffel, Notre-Dame et le Louvre.',
		center: { lat: 48.8566, lng: 2.3522 },
		zoom: 13,
		travelMode: 'WALKING',
		origin: 'Tour Eiffel, Paris, France',
		destination: 'Musee du Louvre, Paris, France',
		waypoints: ['Cathedrale Notre-Dame de Paris, France']
	},
	'new-york': {
		title: 'New York',
		description: 'Trajet urbain entre Times Square, Central Park et Brooklyn Bridge.',
		center: { lat: 40.7128, lng: -74.006 },
		zoom: 12,
		travelMode: 'DRIVING',
		origin: 'Times Square, New York, NY, USA',
		destination: 'Brooklyn Bridge, New York, NY, USA',
		waypoints: ['Central Park, New York, NY, USA']
	},
	madeira: {
		title: 'Madeire',
		description: 'Trajet panoramique au depart de Funchal avec passage par Camara de Lobos.',
		center: { lat: 32.7607, lng: -16.9595 },
		zoom: 11,
		travelMode: 'DRIVING',
		origin: 'Funchal, Madeira, Portugal',
		destination: 'Cabo Girao, Madeira, Portugal',
		waypoints: ['Camara de Lobos, Madeira, Portugal']
	},
	kyoto: {
		title: 'Kyoto',
		description: 'Trajet entre Fushimi Inari, Gion et le Pavillon d\'or.',
		center: { lat: 35.0116, lng: 135.7681 },
		zoom: 12,
		travelMode: 'DRIVING',
		origin: 'Fushimi Inari Taisha, Kyoto, Japan',
		destination: 'Kinkaku-ji, Kyoto, Japan',
		waypoints: ['Gion, Kyoto, Japan']
	}
};

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
let activeRouteKey = 'paris';
let mapInstance;
let directionsRenderer;
let directionsService;

function cleanInput(value, maxLength) {
	return String(value ?? '')
		.replace(/[<>]/g, '')
		.replace(/[\u0000-\u001F\u007F]/g, '')
		.trim()
		.slice(0, maxLength);
}

function setFeedback(message, type) {
	if (!formFeedback) {
		return;
	}

	formFeedback.classList.remove('is-success', 'is-error');
	formFeedback.textContent = message;
	if (type) {
		formFeedback.classList.add(type);
	}
}

function setMapStatus(message, type) {
	if (!mapStatus) {
		return;
	}

	mapStatus.classList.remove('is-error', 'is-success');
	mapStatus.textContent = message;
	if (type) {
		mapStatus.classList.add(type);
	}
}

function updateRouteSelection(routeKey) {
	activeRouteKey = routeKey;

	routeCards.forEach((card) => {
		const isActive = card.dataset.route === routeKey;
		card.classList.toggle('is-selected', isActive);
		card.setAttribute('aria-pressed', String(isActive));
	});

	const route = routeConfigurations[routeKey];
	if (!route) {
		return;
	}

	if (mapRouteTitle) {
		mapRouteTitle.textContent = route.title;
	}

	if (mapRouteDescription) {
		mapRouteDescription.textContent = route.description;
	}
}

function renderFallbackMapState() {
	if (!mapElement) {
		return;
	}

	mapElement.innerHTML = '<div class="map-placeholder"><strong>Google Maps non configure</strong><span>Ajoutez votre cle API dans la balise meta google-maps-api-key pour activer les trajets interactifs.</span></div>';
	setMapStatus('Configuration requise : remplacez YOUR_GOOGLE_MAPS_API_KEY par une cle Google Maps valide.', 'is-error');
}

function renderRoute(routeKey) {
	if (!directionsService || !directionsRenderer) {
		return;
	}

	const route = routeConfigurations[routeKey];
	if (!route) {
		return;
	}

	updateRouteSelection(routeKey);
	mapInstance.setCenter(route.center);
	mapInstance.setZoom(route.zoom);
	setMapStatus(`Chargement du trajet ${route.title}...`);

	directionsService.route({
		origin: route.origin,
		destination: route.destination,
		travelMode: google.maps.TravelMode[route.travelMode],
		waypoints: route.waypoints.map((stopover) => ({
			location: stopover,
			stopover: true
		})),
		optimizeWaypoints: false
	}).then((result) => {
		directionsRenderer.setDirections(result);
		setMapStatus(`Trajet ${route.title} affiche sur la carte.`, 'is-success');
	}).catch(() => {
		setMapStatus(`Impossible de calculer le trajet pour ${route.title}.`, 'is-error');
	});
}

function initializeGoogleMap() {
	if (!mapElement || !window.google?.maps) {
		return;
	}

	const initialRoute = routeConfigurations[activeRouteKey];
	mapInstance = new google.maps.Map(mapElement, {
		center: initialRoute.center,
		zoom: initialRoute.zoom,
		disableDefaultUI: false,
		mapTypeControl: false,
		streetViewControl: false,
		fullscreenControl: true
	});

	directionsService = new google.maps.DirectionsService();
	directionsRenderer = new google.maps.DirectionsRenderer({
		map: mapInstance,
		suppressMarkers: false,
		preserveViewport: false,
		polylineOptions: {
			strokeColor: '#cb5c32',
			strokeWeight: 5
		}
	});

	renderRoute(activeRouteKey);
	window.renderCityRoute = renderRoute;
}

function loadGoogleMapsApi() {
	if (!mapElement) {
		return;
	}

	if (!googleMapsApiKey || googleMapsApiKey === 'YOUR_GOOGLE_MAPS_API_KEY') {
		renderFallbackMapState();
		return;
	}

	if (window.google?.maps) {
		initializeGoogleMap();
		return;
	}

	const existingScript = document.querySelector('script[data-google-maps-loader="true"]');
	if (existingScript) {
		return;
	}

	window.initializeExploreWorldMap = initializeGoogleMap;

	const script = document.createElement('script');
	script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(googleMapsApiKey)}&callback=initializeExploreWorldMap`;
	script.async = true;
	script.defer = true;
	script.dataset.googleMapsLoader = 'true';
	script.onerror = () => {
		setMapStatus('Le chargement de Google Maps a echoue. Verifiez la cle API et les restrictions associees.', 'is-error');
	};
	document.head.appendChild(script);
}

routeCards.forEach((card) => {
	card.setAttribute('aria-pressed', 'false');

	const activateCardRoute = () => {
		const routeKey = card.dataset.route;
		if (!routeKey) {
			return;
		}

		if (!window.google?.maps || !directionsService) {
			updateRouteSelection(routeKey);
			setMapStatus('Ajoutez une cle Google Maps valide pour afficher ce trajet.', 'is-error');
			return;
		}

		renderRoute(routeKey);
	};

	card.addEventListener('click', activateCardRoute);
	card.addEventListener('keydown', (event) => {
		if (event.key === 'Enter' || event.key === ' ') {
			event.preventDefault();
			activateCardRoute();
		}
	});
});

updateRouteSelection(activeRouteKey);
loadGoogleMapsApi();

if (navToggle && navMenu) {
	navToggle.addEventListener('click', () => {
		const isOpen = navMenu.classList.toggle('is-open');
		navToggle.setAttribute('aria-expanded', String(isOpen));
	});

	navMenu.querySelectorAll('a').forEach((link) => {
		link.addEventListener('click', () => {
			navMenu.classList.remove('is-open');
			navToggle.setAttribute('aria-expanded', 'false');
		});
	});

	document.addEventListener('keydown', (event) => {
		if (event.key === 'Escape') {
			navMenu.classList.remove('is-open');
			navToggle.setAttribute('aria-expanded', 'false');
		}
	});
}

filterButtons.forEach((button) => {
	button.setAttribute('aria-pressed', button.classList.contains('is-active') ? 'true' : 'false');

	button.addEventListener('click', () => {
		const selectedFilter = button.dataset.filter;

		filterButtons.forEach((item) => {
			item.classList.remove('is-active');
			item.setAttribute('aria-pressed', 'false');
		});

		button.classList.add('is-active');
		button.setAttribute('aria-pressed', 'true');

		cards.forEach((card) => {
			const categories = (card.dataset.category || '').split(/\s+/).filter(Boolean);
			const shouldShow = selectedFilter === 'all' || categories.includes(selectedFilter);

			card.classList.toggle('is-hidden', !shouldShow);

			if (shouldShow) {
				card.classList.add('is-visible');
			}
		});
	});
});

if (surpriseButton && featuredDestination) {
	surpriseButton.addEventListener('click', () => {
		const randomIndex = Math.floor(Math.random() * surpriseDestinations.length);
		featuredDestination.textContent = surpriseDestinations[randomIndex];
	});
}

if (rotateNoteButton && experienceNote) {
	let noteIndex = 0;

	rotateNoteButton.addEventListener('click', () => {
		noteIndex = (noteIndex + 1) % experienceNotes.length;
		experienceNote.textContent = experienceNotes[noteIndex];
	});
}

if (contactForm && formFeedback) {
	contactForm.addEventListener('submit', (event) => {
		event.preventDefault();

		const formData = new FormData(contactForm);
		const name = cleanInput(formData.get('name'), 80);
		const email = cleanInput(formData.get('email'), 120);
		const destination = cleanInput(formData.get('destination'), 60);
		const message = cleanInput(formData.get('message'), 800);

		if (name.length < 2) {
			setFeedback('Nom invalide. Merci de saisir au moins 2 caracteres.', 'is-error');
			return;
		}

		if (!emailPattern.test(email)) {
			setFeedback('Email invalide. Verifiez le format.', 'is-error');
			return;
		}

		if (!destination) {
			setFeedback('Merci de choisir une destination.', 'is-error');
			return;
		}

		if (message.length > 0 && message.length < 10) {
			setFeedback('Le message doit contenir au moins 10 caracteres.', 'is-error');
			return;
		}

		setFeedback(`Merci ${name}, votre demande pour ${destination} a bien ete envoyee.`, 'is-success');
		contactForm.reset();
	});
}

const counterObserver = new IntersectionObserver((entries, observer) => {
	entries.forEach((entry) => {
		if (!entry.isIntersecting) {
			return;
		}

		const element = entry.target;
		const target = Number(element.dataset.count);
		const duration = 1000;
		const start = performance.now();

		const updateCounter = (currentTime) => {
			const progress = Math.min((currentTime - start) / duration, 1);
			element.textContent = String(Math.round(progress * target));

			if (progress < 1) {
				window.requestAnimationFrame(updateCounter);
			}
		};

		window.requestAnimationFrame(updateCounter);
		observer.unobserve(element);
	});
}, { threshold: 0.5 });

counterElements.forEach((element) => counterObserver.observe(element));

const revealObserver = new IntersectionObserver((entries, observer) => {
	entries.forEach((entry) => {
		if (entry.isIntersecting) {
			entry.target.classList.add('reveal', 'is-visible');
			observer.unobserve(entry.target);
		}
	});
}, { threshold: 0.12 });

revealElements.forEach((element) => {
	element.classList.add('reveal');
	revealObserver.observe(element);
});
